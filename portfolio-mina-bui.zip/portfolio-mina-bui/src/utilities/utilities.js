// General Utilities

// Capitalize the first letter in a string...
export const capitalizeFirstLetter = (string) => {
    return string.charAt(0).toUpperCase() + string.slice(1);
}